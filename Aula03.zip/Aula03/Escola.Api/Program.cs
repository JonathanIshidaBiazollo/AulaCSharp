using Escola.Api.Controllers;
using Escola.Contexts;
using Escola.Services;
using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Microsoft.EntityFrameworkCore;
using Scalar.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers(
    c => c.Conventions.Add(new ApiVisibilityConvention())    
);
builder.Services.AddScoped<AlunoService>();

var connstring = builder.Configuration.GetConnectionString("Postgres");
builder.Services.AddDbContext<EscolaDbContext>(o => o.UseNpgsql(connstring));

// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment()) {
    app.MapOpenApi();
}

app.MapScalarApiReference();

app.MapControllers();

app.Run();

//PIPELINES
//tendo que passar todos os parâmetros
//var controller = new AlunoController(new AlunoService(new EscolaDbContext(null, "")));

//Injeção de depencdÊncia, o asp net que cria o parametro e passa para o construtor, melhor, mais conciso e caso precise aumentar ou diminuir parâmetros, não vai dar erro
var controller2 = app.Services.GetService<AlunoController>();