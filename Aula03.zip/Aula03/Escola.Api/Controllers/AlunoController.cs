﻿using Escola.Models;
using Escola.Services;
using Microsoft.AspNetCore.Mvc;

namespace Escola.Api.Controllers {
    [Route("api/[controller]")]
    public class AlunoController : ControllerBase{

        
        private AlunoService service;

        public AlunoController(AlunoService service) {
            this.service = service;
        }
        //[HttpGet]

        //public IActionResult Consultar() {
        //    var alunos = service.Consultar();
        //    return Ok(alunos);
        //}

        [HttpGet]
        public IActionResult Consultar(string pesquisa) {
            var alunos = string.IsNullOrEmpty(pesquisa) ? service.Consultar() :  service.Consultar(pesquisa);
            return Ok(alunos);
        }

        [HttpPost]
        public IActionResult Cadastrar([FromBody] Aluno aluno) {
            var sucesso = service.Criar(aluno, out var erros);
            if (sucesso) {
                return Ok(aluno);
            }
            return UnprocessableEntity(erros);
        }
    }
}
