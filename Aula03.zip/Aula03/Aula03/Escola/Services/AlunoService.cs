﻿using Escola.Contexts;
using Escola.Models;
using System.ComponentModel.DataAnnotations;

namespace Escola.Services {
    public class AlunoService {

        private EscolaDbContext context;

        public AlunoService(EscolaDbContext context) {
            this.context = context;

        }

        public AlunoService() : this(new EscolaDbContext(ConectionString)) { //não dá para usar o construtor se não forem constantes

        }

        //Jeito melhor de fazer
        //public AlunoService() {
        //    var ctx = new EscolaDbContext(ConectionString);
        //    this.context = ctx;

        //}

        private const string ConectionString =
            "Server=172.16.96.13;Port=5432;Database=jonathan;User Id=postgres;Password=1234";

        private List<Aluno> lista = new List<Aluno> {
            new Aluno{ Codigo = "1", Nome = "Jonathan", Email = "jonathan@email", DataNascimento = DateTime.Parse("18/03/1995") },
            new Aluno{ Codigo = "2", Nome = "Leonardo", Email = "leo@email", DataNascimento = DateTime.Parse("07/12/2006") },
            new Aluno{ Codigo = "3", Nome = "Maria", Email = "maria@email", DataNascimento = DateTime.Parse("09/04/1995") }
        };

        //public List<Aluno> Consultar() {//encapsulamento, proteger o dado da classe, pois a lista é privada
        //    return lista.ToList();//Cópia da lista original
        //}

        public List<Aluno> Consultar(string pesquisa) {

            bool FiltrarAluno(Aluno a) {
                return a.Nome.Contains(pesquisa);
            }
            var alunos = Consultar();

            var resultado = new List<Aluno>();
            //sorting
            foreach (var aluno in alunos) {
                if (aluno.Nome.Contains(pesquisa)) {
                    resultado.Add(aluno);
                }
            }
            return resultado;
        }

        public List<Aluno> Consultar() {

            ////LINQ por métodos (metódico)
            //var resultado = alunos
            //    .Where((aluno) => aluno.Nome.Contains(pesquisa))
            //    .OrderBy(x => x.Nome);//Expressão lambda

            ////LINQ por sintaxe (sintático)
            ////é igual do jeito de cima, vai do seu gosto
            //var resultado2 = from aluno in alunos
            //                 where aluno.Nome.Contains(pesquisa)
            //                 orderby aluno.Nome
            //                 select aluno;

            //return resultado.ToList();

            //var conexao = new NpgsqlConnection(ConectionString);
            //conexao.Open();
            //var sql = """
            //            select codigo, nome, email, datanascimento 
            //            from alunos
            //        """;

            //var comando = new NpgsqlCommand(sql, conexao);

            //var leitor = comando.ExecuteReader();

            //var resultado = new List<Aluno>();

            //while (leitor.Read()) {
            //    var aluno = new Aluno() {

            //        Codigo = leitor.GetString(0),
            //        Nome = leitor.GetString(1),
            //        Email = leitor.GetString(2),
            //        DataNascimento = leitor.GetDateTime(3)
            //    };

            //    resultado.Add(aluno);

            //}

            //return resultado;

            //Usando ORM
            var resultado2 = context.Alunos
                .OrderBy(a => a.Nome)
                .ToList();
            return resultado2;

        }



        public bool Criar(Aluno aluno, out List<ValidationResult> erros) {
            if (!Validar(aluno, out erros)) {
                return false;
            }
            ////lista.Add(aluno);
            ////return true;
            //var conexao = new NpgsqlConnection(ConectionString);
            //conexao.Open();
            ////Jeito errado, alguém pode dar sql injection
            ////var sql = $"""
            ////        INSERT INTO alunos(
            ////            codigo,
            ////            nome,
            ////            email,
            ////            datanascimento
            ////        )VALUES(
            ////            '{aluno.Codigo}', 
            ////            '{aluno.Nome}', 
            ////            '{aluno.Email}', 
            ////            '{aluno.DataNascimento}'
            ////        );
            ////    """;

            ////Jeito certo com prepared statements
            //var sql = $"""
            //        INSERT INTO alunos(
            //            codigo,
            //            nome,
            //            email,
            //            datanascimento
            //        )VALUES(
            //            @codigo, 
            //            @p1,
            //            @p2,
            //            @p3
            //        );
            //    """;

            //var comando = new NpgsqlCommand(sql, conexao);

            //comando.Parameters.Add("codigo", NpgsqlDbType.Text).Value = aluno.Codigo;
            //comando.Parameters.Add("p1", NpgsqlDbType.Text).Value = aluno.Nome;
            //comando.Parameters.Add("p2", NpgsqlDbType.Text).Value = aluno.Email;
            //comando.Parameters.Add("p3", NpgsqlDbType.Timestamp).Value = aluno.DataNascimento.Date;

            //var linhas = comando.ExecuteNonQuery();
            //return linhas == 1;

            //Com ORM
            context.Add(aluno);//INSERT INTO
            context.SaveChanges();//Commit
            return true;
        }

        public bool Validar(Aluno aluno, out List<ValidationResult> erros) {
            var context = new ValidationContext(aluno);
            erros = new List<ValidationResult>();
            return Validator.TryValidateObject(aluno, context, erros, true);
        }

        public bool Excluir(string codigo) {
            var aluno = lista.FirstOrDefault(x => x.Codigo == codigo);//serve para pegar o aluno da lista que foi clicado
            if (aluno == null) {
                return false;
            }

            lista.Remove(aluno);
            return true;
        }
    }
}


//Serviço(Carro)
//Carro(Motorista)


//var c = new carro(jose)

//var s = new serviço(c)