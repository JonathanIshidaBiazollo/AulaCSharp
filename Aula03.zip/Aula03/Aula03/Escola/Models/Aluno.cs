﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Escola.Models{
    public class Aluno{
        [Required]
        [StringLength(10)]
        public string Codigo { get; set; }

        [Required]
        [StringLength(80, MinimumLength = 6)]
        [RegularExpression("^[a-zA-Z]+$")]
        public string Nome {  get; set; }

        private string email;

        [EmailAdress]
        public string Email {
            get { return this.email; }
            set{
                this.email = value.ToLower().Trim();
            }
        }
        public DateTime DataNascimento {  get; set; }

        [Range(15, 100)]
        public int Idade {
            get {
                var hoje = DateTime.Today;
                var idade = hoje.Year - DataNascimento.Year;
                var hojeAnoNascimento = hoje.AddYears(-idade);
                if(DataNascimento > hojeAnoNascimento) {
                    idade--;
                }
                return idade;
            }
        }

        public virtual void PrintDados(){//virtual, quer dizer que ela pode ser sobreescrit
            Console.WriteLine("Código: {0}", Codigo);//só isso já chama o Método Get
            Console.WriteLine("Nome: {0}", Nome);
            Console.WriteLine("Email: {0}", Email);
            Console.WriteLine("Data Nascimento: {0:dd} de {0:MMMM} de {0:yyyy} ({0:dddd})", DataNascimento);
            Console.WriteLine("Idade: {0}", Idade);
        }




    }
}
