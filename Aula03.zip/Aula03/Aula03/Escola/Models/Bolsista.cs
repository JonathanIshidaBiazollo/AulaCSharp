﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Escola.Models{
    internal class Bolsista : Aluno{
        public int PorcentagemDesconto { get; set; }//especificando o tipo de aluno

        public override void PrintDados(){
            Console.WriteLine("ALuno Bolsista");
            base.PrintDados();//Chamando O método que está sendo sobreescrito pare ser usado tbm
            Console.WriteLine("Desconto: {0}%", PorcentagemDesconto);
        }
    }
}
