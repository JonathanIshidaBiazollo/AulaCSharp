﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Escola.Models
{
    internal class Class1
    {
    }
}
