﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Escola.Models{
    internal class AlunoIntercambio :  Aluno{
        public string PaisOrigem {  get; set; }
    }
}
