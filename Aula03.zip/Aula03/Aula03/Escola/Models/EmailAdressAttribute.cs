﻿namespace Escola.Models {
    internal class EmailAdressAttribute : Attribute {
    }
}