﻿
using Escola.Models;
using Escola.Services;


/*
Console.WriteLine(aluno.Idade);

/*
aluno.PrintDados();

//var bolsista = new Bolsista();
var bolsista = new Bolsista{
    Nome = "Aluno Bolsista",
    Codigo = "5664",
    PorcentagemDesconto = 50
};
bolsista.PrintDados();//polimorfismo

var intercambio = new AlunoIntercambio();

Aluno a;

a = aluno;
a = bolsista;
a = intercambio;

var lista = new List<Aluno>();

lista.Add(aluno);
lista.Add(bolsista);
lista.Add(intercambio);

foreach(var item in lista){
    item.PrintDados() ;
}
*/


var service = new AlunoService();

while (true) {
    Console.WriteLine("1 - Consultar alunos");
    Console.WriteLine("2 - Cadastrar alunos");

    Console.Write("Digite a opção: ");

    
    int opcao = 0;
    try {
        //Exemplo de recursão infinita, try catch não pega esse tipo de erro nesse caso
        /*
        void Recursao() {
            Recursao();
        }
        Recursao();
        */
        opcao = int.Parse(Console.ReadLine());
    } catch (OverflowException ex) {
        Console.WriteLine("Opção inválida! Valor fora dos limites  {0}", ex.Message);
    } catch (Exception ex) {
        Console.WriteLine("Opção inválida {0}", ex.Message);
    }


    if (opcao == 1) {
        Console.Clear();
        var alunos = service.Consultar();
        if (alunos.Count == 0) {
            Console.WriteLine("Lista VAzia");
        }
        foreach (var item in alunos) {
            item.PrintDados();
            Console.WriteLine("================");
            Console.WriteLine();
        }
    } else if (opcao == 2) {
        Console.Clear();
        Console.WriteLine("Digite o nome: ");
        var nome = Console.ReadLine();

        Console.WriteLine("Digite o email: ");
        var email = Console.ReadLine();

        Console.WriteLine("Digite o codigo: ");
        var codigo = Console.ReadLine();

        Console.WriteLine("Digite a data de nascimento: ");
        var data = DateTime.Parse(Console.ReadLine());

        var aluno = new Aluno();


        //aluno.setNome(nome);
        aluno.Nome = nome;
        aluno.Email = email;
        aluno.DataNascimento = data;
        aluno.Codigo = codigo;

        var sucesso = service.Criar(aluno, out var erros);

        if (sucesso) {
            Console.WriteLine("Aluno cadastrado com sucesso");
            aluno.PrintDados();
        } else {
            Console.WriteLine("Falha no cadastro");

            foreach(var erro in erros) {
                Console.WriteLine("{0}: {1}",
                    erro.MemberNames.First(),
                    erro.ErrorMessage);
            }
        }
    }
    
}