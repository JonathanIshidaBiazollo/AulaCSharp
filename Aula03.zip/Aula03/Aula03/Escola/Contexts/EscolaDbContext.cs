﻿using Escola.Models;
using Microsoft.EntityFrameworkCore;

namespace Escola.Contexts {
    public class EscolaDbContext : DbContext {

        private string connectionString;
        public EscolaDbContext(string connString) {
            this.connectionString = connString;
        }

        //esse construtor está chamando o construtor do DbContext
        public EscolaDbContext(DbContextOptions opt) : base(opt) {

        }

        public DbSet<Aluno> Alunos => Set<Aluno>();

        protected override void OnModelCreating(ModelBuilder modelBuilder) {
            var entityAluno = modelBuilder.Entity<Aluno>();

            entityAluno.ToTable("alunos");
            entityAluno.Property(c => c.Codigo).HasColumnName("codigo");
            entityAluno.Property(c => c.Nome).HasColumnName("nome");
            entityAluno.Property(c => c.DataNascimento).HasColumnName("datanascimento");
            entityAluno.Property(c => c.Email).HasColumnName("email");
            entityAluno.HasKey(c => c.Codigo);

            base.OnModelCreating(modelBuilder);
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder) {
            if (!string.IsNullOrEmpty(connectionString)) {
                optionsBuilder.UseNpgsql(connectionString);
            }
            base.OnConfiguring(optionsBuilder);
        }
    }
}
