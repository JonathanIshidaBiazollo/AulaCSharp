﻿using Escola.Models;
using Escola.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Escola.Desktop.Screen {
    public partial class ListarUsuario : Form {

        private AlunoService service;
        public ListarUsuario(AlunoService service) {
            this.service = service;
            InitializeComponent();
            this.StartPosition = FormStartPosition.CenterScreen;
            CarregarDados();
        }

        public void CarregarDados() {
            var alunos = service.Consultar();
            CarregarDadosTabela(alunos);
        }

        private void ListarUsuario_Load(object sender, EventArgs e) {

        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e) {
            var resultado = service.Consultar(txtPesquisa.Text);

            CarregarDadosTabela(resultado);

        }

        private void CarregarDadosTabela(List<Aluno> lista) {
            dataGridView1.Rows.Clear();
            foreach (var aluno in lista) {
                dataGridView1.Rows.Add(
                    aluno.Codigo,
                    aluno.Nome,
                    aluno.Email,
                    aluno.DataNascimento.ToString("dd/MM/yyyy"),
                    aluno.Idade

                 );
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e) {
            if (dataGridView1.SelectedRows.Count == 0) {//Se não selecionar nenhuma linha e somente clicar em excluir
                //MessageBox.Show("Selecione um aluno para excluir");
                lblMensagem.Text = "Selecione um aluno para excluir";
                return;
            }

            var linha = dataGridView1.SelectedRows[0];//

            string codigo = linha.Cells[0].Value.ToString();//pegando o código pelo valor da célula

            var resultado = MessageBox.Show(
                "Deseja realmente excluir?",
                "Confirma a exclusão?",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
                );

            if( resultado == DialogResult.Yes ) {
                if (service.Excluir(codigo)){
                    //chamo a exclusão
                    //MessageBox.Show("Aluno excluído com sucesso.");
                    lblMensagem.Text = "Aluno excluído com sucesso!";
                    CarregarDados();
                }else { 
                    //MessageBox.Show("Aluno, não encontrado");   
                    lblMensagem.Text = "Aluno não encontrado";
                }
                
            }
        }
    }
}
