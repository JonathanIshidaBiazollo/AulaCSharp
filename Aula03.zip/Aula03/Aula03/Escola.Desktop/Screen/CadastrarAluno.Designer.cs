﻿namespace Escola.Desktop.Screen {
    partial class CadastrarAluno {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(CadastrarAluno));
            primaryButton1 = new Escola.Desktop.Componentes.PrimaryButton();
            Nome = new Label();
            label2 = new Label();
            label3 = new Label();
            txtNome = new TextBox();
            txtEmail = new TextBox();
            txtCodigo = new TextBox();
            label1 = new Label();
            txtDataNascimento = new DateTimePicker();
            label = new Label();
            lblMensagem = new Label();
            btnSair = new Escola.Desktop.Componentes.PrimaryButton();
            SuspendLayout();
            // 
            // primaryButton1
            // 
            primaryButton1.BackColor = Color.DarkBlue;
            primaryButton1.Font = new Font("Arial", 12F);
            primaryButton1.ForeColor = Color.White;
            primaryButton1.Location = new Point(282, 273);
            primaryButton1.Margin = new Padding(3, 4, 3, 4);
            primaryButton1.Name = "primaryButton1";
            primaryButton1.Size = new Size(159, 68);
            primaryButton1.TabIndex = 0;
            primaryButton1.Text = "Cadastrar";
            primaryButton1.UseVisualStyleBackColor = false;
            primaryButton1.Click += primaryButton1_Click;
            // 
            // Nome
            // 
            Nome.AutoSize = true;
            Nome.Location = new Point(61, 93);
            Nome.Name = "Nome";
            Nome.Size = new Size(50, 20);
            Nome.TabIndex = 2;
            Nome.Text = "Nome";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(61, 147);
            label2.Name = "label2";
            label2.Size = new Size(46, 20);
            label2.TabIndex = 3;
            label2.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(61, 209);
            label3.Name = "label3";
            label3.Size = new Size(147, 20);
            label3.TabIndex = 4;
            label3.Text = "Data De Nascimento";
            // 
            // txtNome
            // 
            txtNome.Location = new Point(232, 93);
            txtNome.Margin = new Padding(3, 4, 3, 4);
            txtNome.Name = "txtNome";
            txtNome.Size = new Size(114, 27);
            txtNome.TabIndex = 5;
            // 
            // txtEmail
            // 
            txtEmail.Location = new Point(232, 147);
            txtEmail.Margin = new Padding(3, 4, 3, 4);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(114, 27);
            txtEmail.TabIndex = 6;
            // 
            // txtCodigo
            // 
            txtCodigo.Location = new Point(232, 32);
            txtCodigo.Margin = new Padding(3, 4, 3, 4);
            txtCodigo.Name = "txtCodigo";
            txtCodigo.Size = new Size(114, 27);
            txtCodigo.TabIndex = 9;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(61, 32);
            label1.Name = "label1";
            label1.Size = new Size(58, 20);
            label1.TabIndex = 8;
            label1.Text = "Código";
            // 
            // txtDataNascimento
            // 
            txtDataNascimento.Location = new Point(232, 209);
            txtDataNascimento.Margin = new Padding(3, 4, 3, 4);
            txtDataNascimento.Name = "txtDataNascimento";
            txtDataNascimento.Size = new Size(228, 27);
            txtDataNascimento.TabIndex = 10;
            // 
            // label
            // 
            label.AutoSize = true;
            label.Location = new Point(544, 32);
            label.Name = "label";
            label.Size = new Size(82, 20);
            label.TabIndex = 11;
            label.Text = "⚠️ AVISO: ";
            // 
            // lblMensagem
            // 
            lblMensagem.AutoSize = true;
            lblMensagem.Location = new Point(655, 32);
            lblMensagem.Name = "lblMensagem";
            lblMensagem.Size = new Size(18, 20);
            lblMensagem.TabIndex = 12;
            lblMensagem.Text = "...";
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.FromArgb(192, 64, 0);
            btnSair.Font = new Font("Arial", 25F);
            btnSair.ForeColor = Color.White;
            btnSair.Location = new Point(467, 273);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(159, 75);
            btnSair.TabIndex = 13;
            btnSair.Text = "🚪↩️ ";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += btnSair_Click;
            // 
            // CadastrarAluno
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            //BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(914, 600);
            Controls.Add(btnSair);
            Controls.Add(lblMensagem);
            Controls.Add(label);
            Controls.Add(txtDataNascimento);
            Controls.Add(txtCodigo);
            Controls.Add(label1);
            Controls.Add(txtEmail);
            Controls.Add(txtNome);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(Nome);
            Controls.Add(primaryButton1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "CadastrarAluno";
            Text = "CadastrarAluno";
            Load += CadastrarAluno_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Componentes.PrimaryButton primaryButton1;
        private Label Nome;
        private Label label2;
        private Label label3;
        private TextBox txtNome;
        private TextBox txtEmail;
        private TextBox txtCodigo;
        private Label label1;
        private DateTimePicker txtDataNascimento;
        private Label label;
        private Label lblMensagem;
        private Componentes.PrimaryButton btnSair;
    }
}