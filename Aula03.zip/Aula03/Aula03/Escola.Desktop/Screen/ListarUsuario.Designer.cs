﻿namespace Escola.Desktop.Screen {
    partial class ListarUsuario {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing) {
            if (disposing && (components != null)) {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent() {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ListarUsuario));
            dataGridView1 = new DataGridView();
            Codigo = new DataGridViewTextBoxColumn();
            Nome = new DataGridViewTextBoxColumn();
            Email = new DataGridViewTextBoxColumn();
            DataDeNascimento = new DataGridViewTextBoxColumn();
            Idade = new DataGridViewTextBoxColumn();
            label1 = new Label();
            btnSair = new Button();
            button1 = new Button();
            txtPesquisa = new TextBox();
            btnExcluir = new Button();
            Label = new Label();
            lblMensagem = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Columns.AddRange(new DataGridViewColumn[] { Codigo, Nome, Email, DataDeNascimento, Idade });
            dataGridView1.Location = new Point(14, 92);
            dataGridView1.Margin = new Padding(3, 4, 3, 4);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1049, 503);
            dataGridView1.TabIndex = 4;
            // 
            // Codigo
            // 
            Codigo.HeaderText = "Código";
            Codigo.MinimumWidth = 6;
            Codigo.Name = "Codigo";
            Codigo.Width = 250;
            // 
            // Nome
            // 
            Nome.HeaderText = "Nome";
            Nome.MinimumWidth = 6;
            Nome.Name = "Nome";
            Nome.Width = 250;
            // 
            // Email
            // 
            Email.HeaderText = "Email";
            Email.MinimumWidth = 6;
            Email.Name = "Email";
            Email.Width = 125;
            // 
            // DataDeNascimento
            // 
            DataDeNascimento.HeaderText = "Data de Nascimento";
            DataDeNascimento.MinimumWidth = 6;
            DataDeNascimento.Name = "DataDeNascimento";
            DataDeNascimento.Width = 250;
            // 
            // Idade
            // 
            Idade.HeaderText = "Idade";
            Idade.MinimumWidth = 6;
            Idade.Name = "Idade";
            Idade.Width = 125;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Monotype Corsiva", 36F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label1.Location = new Point(424, 9);
            label1.Name = "label1";
            label1.Size = new Size(186, 72);
            label1.TabIndex = 5;
            label1.Text = "Alunos";
            // 
            // btnSair
            // 
            btnSair.BackColor = Color.FromArgb(192, 64, 0);
            btnSair.Font = new Font("Segoe UI", 20.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnSair.ForeColor = SystemColors.ButtonHighlight;
            btnSair.Location = new Point(852, 18);
            btnSair.Margin = new Padding(3, 4, 3, 4);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(133, 57);
            btnSair.TabIndex = 6;
            btnSair.Text = "🚪↩️ ";
            btnSair.UseVisualStyleBackColor = false;
            btnSair.Click += button3_Click;
            // 
            // button1
            // 
            button1.Location = new Point(316, 46);
            button1.Margin = new Padding(3, 4, 3, 4);
            button1.Name = "button1";
            button1.Size = new Size(86, 31);
            button1.TabIndex = 7;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtPesquisa
            // 
            txtPesquisa.Location = new Point(63, 48);
            txtPesquisa.Margin = new Padding(3, 4, 3, 4);
            txtPesquisa.Name = "txtPesquisa";
            txtPesquisa.Size = new Size(247, 27);
            txtPesquisa.TabIndex = 8;
            // 
            // btnExcluir
            // 
            btnExcluir.BackColor = Color.Red;
            btnExcluir.Location = new Point(638, 16);
            btnExcluir.Name = "btnExcluir";
            btnExcluir.Size = new Size(132, 57);
            btnExcluir.TabIndex = 9;
            btnExcluir.Text = "🗑️ Excluir";
            btnExcluir.UseVisualStyleBackColor = false;
            btnExcluir.Click += btnExcluir_Click;
            // 
            // Label
            // 
            Label.AutoSize = true;
            Label.BackColor = SystemColors.Menu;
            Label.ForeColor = SystemColors.ActiveCaptionText;
            Label.Location = new Point(63, 18);
            Label.Name = "Label";
            Label.Size = new Size(82, 20);
            Label.TabIndex = 10;
            Label.Text = "⚠️ AVISO: ";
            // 
            // lblMensagem
            // 
            lblMensagem.AutoSize = true;
            lblMensagem.BackColor = SystemColors.Menu;
            lblMensagem.ForeColor = SystemColors.ActiveCaptionText;
            lblMensagem.Location = new Point(152, 19);
            lblMensagem.Name = "lblMensagem";
            lblMensagem.Size = new Size(18, 20);
            lblMensagem.TabIndex = 11;
            lblMensagem.Text = "...";
            // 
            // ListarUsuario
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            //BackgroundImage = (Image)resources.GetObject("$this.BackgroundImage");
            ClientSize = new Size(1079, 611);
            Controls.Add(lblMensagem);
            Controls.Add(Label);
            Controls.Add(btnExcluir);
            Controls.Add(txtPesquisa);
            Controls.Add(button1);
            Controls.Add(btnSair);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Margin = new Padding(3, 4, 3, 4);
            Name = "ListarUsuario";
            Text = "ListarUsuario";
            Load += ListarUsuario_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Label label1;
        private Button btnSair;
        private Button button1;
        private TextBox txtPesquisa;
        private DataGridViewTextBoxColumn Codigo;
        private DataGridViewTextBoxColumn Nome;
        private DataGridViewTextBoxColumn Email;
        private DataGridViewTextBoxColumn DataDeNascimento;
        private DataGridViewTextBoxColumn Idade;
        private Button btnExcluir;
        private Label Label;
        private Label lblMensagem;
    }
}