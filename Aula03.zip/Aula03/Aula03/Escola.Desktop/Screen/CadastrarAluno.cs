﻿using Escola.Models;
using Escola.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Escola.Desktop.Screen {
    public partial class CadastrarAluno : Form {
        private AlunoService service;
        public CadastrarAluno(AlunoService service) {
            this.service = service;
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
        }

        private void CadastrarAluno_Load(object sender, EventArgs e) {

        }

        private void primaryButton1_Click(object sender, EventArgs e) {
            var aluno = new Aluno {
                Codigo = txtCodigo.Text,
                Nome = txtNome.Text,
                Email = txtEmail.Text,
                DataNascimento = txtDataNascimento.Value.Date.ToUniversalTime(),
            };

            var sucesso = service.Criar(aluno, out var erros);

            if (sucesso) {
                //MessageBox.Show("Aluno cadastrado com sucesso");
                //this.Close();
                lblMensagem.Text = "Aluno cadastrado com sucesso" +
                                "\n Cadastre um novo aluno ou veja" +
                                "\n na lista quais alunos já foram" +
                                "\n cadastrados.";
                txtCodigo.Clear();
                txtNome.Clear();
                txtEmail.Clear();

                txtCodigo.Focus();
            } else {
                //MessageBox.Show("Falha na criação do aluno");
                lblMensagem.Text = "Falha na criação do aluno";
                Debug.WriteLine($" Erros >{erros}");
            }
        }

        private void btnSair_Click(object sender, EventArgs e) {
            this.Close();
        }
    }
}
