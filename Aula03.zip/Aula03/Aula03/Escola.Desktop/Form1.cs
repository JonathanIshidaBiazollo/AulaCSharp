using Escola.Desktop.Screen;
using Escola.Services;

namespace Escola.Desktop {
    public partial class Form1 : Form {

        private AlunoService service;
        public Form1() {
            service = new AlunoService();
            InitializeComponent();

            
            this.StartPosition = FormStartPosition.CenterScreen;

        }

        private void label1_Click(object sender, EventArgs e) {

        }

        private void button1_Click(object sender, EventArgs e) {
            /*
            button1.Location = new Point(
                button1.Location.X + 30,
                button1.Location.Y + 10
                );
            */
            var tela = new ListarUsuario(service);
            //tela.Show(this);
            tela.ShowDialog(this);
        }

        private void button2_Click(object sender, EventArgs e) {
            var tela = new CadastrarAluno(service);
            tela.ShowDialog(this);
        }

        private void button3_Click(object sender, EventArgs e) {
            this.Close();
        }

        private void btnSair1_Click(object sender, EventArgs e) {

        }
    }
}
