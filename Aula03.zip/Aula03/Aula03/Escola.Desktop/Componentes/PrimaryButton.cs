﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace Escola.Desktop.Componentes {
    public partial class PrimaryButton : Button {

        public override Color BackColor {
            get => base.BackColor; 
            set => base.BackColor = value;
            //Se não quiser deixar mudar a cor por exemplo
            /*
            get => Color.DarkBlue;
            set;
            */
        }
        public PrimaryButton() {
            BackColor = Color.FromArgb(192, 64, 0);
            Font = new Font("Arial", 25);
            Size = new Size(250, 60);
            ForeColor = Color.White;
            Text = "teste";

            InitializeComponent();
        }
    }
}
