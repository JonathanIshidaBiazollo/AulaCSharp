﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace Escola.Desktop.Componentes {
    public partial class btnSair : Button {

        public override Color BackColor { 
            get => base.BackColor;
            set => base.BackColor = value; 
        }
        public btnSair() {
            BackColor = Color.Red;
            Font = new Font("Arial", 36);
            Size = new Size(150, 60);
            ForeColor = Color.White;
            Text = "Sair";
            InitializeComponent();
        }

        public btnSair(IContainer container) {
            container.Add(this);

            InitializeComponent();
        }
    }
}
