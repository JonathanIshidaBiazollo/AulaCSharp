﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Text;

namespace Escola.Desktop.Componentes {

 public partial class btnPorta : Button
{
    public btnPorta()
{
    InitializeComponent();

    BackColor = Color.FromArgb(192, 64, 0);
    Font = new Font("Arial", 36);
    Size = new Size(150, 60);
    ForeColor = Color.White;
    Text = "TESTE";
}

public btnPorta(IContainer container)
{
    container.Add(this);
    InitializeComponent();

    BackColor = Color.FromArgb(192, 64, 0);
    Font = new Font("Arial", 36);
    Size = new Size(150, 60);
    ForeColor = Color.White;
    Text = "TESTE";
}

}
}
