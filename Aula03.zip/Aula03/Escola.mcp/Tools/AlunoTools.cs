﻿using Escola.Models;
using Escola.Services;
using ModelContextProtocol.Server;
using System.ComponentModel;

namespace Escola.mcp.Tools {
    [McpServerToolType]
    public class AlunoTools {

        private AlunoService service;

        public AlunoTools(AlunoService service) {
            this.service = service;
        }

        [McpServerTool]
        [Description("Retorna todos os alunos do sistema")]
        public List<Aluno> ConsultarAlunos() {
            var alunos = service.Consultar();
            return alunos;
        }

        [McpServerTool]
        [Description("Cria um aluno no sistema com todos os dados necessários")]
        public object<Aluno> CriarAluno(
            string codigo,
            string nome,
            DateTime dataNascimento,
            string email
        ) {
            var aluno = new Aluno();
            {
                Codigo = codigo,
                Nome = nome,
                Email = email,
                DataNascimento = dataNascimento.ToUniversalTime()
            };
        }
        EnvironmentVariablesExtensions 

        }
    }
}
