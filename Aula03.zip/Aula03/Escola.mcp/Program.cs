
using Escola.Contexts;
using Escola.Services;
using Microsoft.EntityFrameworkCore;
using ModelContextProtocol.AspNetCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddMcpServer()
    .WithHttpTransport(options => {
        options.SessionMode = HttpServerSessionMode.Stateless;
    })
    .WithToolsFromAssembly();


builder.Services.AddScoped<AlunoService>();

var connstring = builder.Configuration.GetConnectionString("Postgres");
builder.Services.AddDbContext<EscolaDbContext>(o => o.UseNpgsql(connstring));

var app = builder.Build();
app.MapMcp("/mcp");

app.Run();
